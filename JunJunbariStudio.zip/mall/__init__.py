default_app_config = "mall.apps.MallConfig"
