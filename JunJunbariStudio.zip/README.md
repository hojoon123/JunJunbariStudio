# JunJunbariStudio
 2024 종합 포트폴리오를 위한 초석1번 Framework Django  DB PostgreSQL Deploy AWS EC2 핵심 기능 : mall & payment & main DB 
